const NotFound = () => {
  return <div className="container">NotFound</div>;
};

export default NotFound;
