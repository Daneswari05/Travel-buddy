import logos_black from "./../assets/images/logos_black.png";
import illustration from "./../assets/images/illustration.svg";
import chooseus from "./../assets/images/chooseus.svg";

//features
import feature1 from "./../assets/images/feature1.svg";
import feature2 from "./../assets/images/feature2.svg";
import feature3 from "./../assets/images/feature3.svg";

import world from "./../assets/images/world.svg";

export default {
  logos_black,
  illustration,
  chooseus,
  feature1,
  feature2,
  feature3,
  world,
};
